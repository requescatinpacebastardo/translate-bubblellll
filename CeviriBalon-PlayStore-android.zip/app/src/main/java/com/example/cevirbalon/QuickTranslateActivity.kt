package com.example.cevirbalon

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

/**
 * Android'in "Metin seç -> Çevir" menüsünden tetiklenir (ACTION_PROCESS_TEXT).
 * Hiçbir hassas izin istemez, Play Store politikalarına uygundur.
 */
class QuickTranslateActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val selectedText = intent?.getCharSequenceExtra(android.content.Intent.EXTRA_PROCESS_TEXT)?.toString()
        if (selectedText.isNullOrBlank()) { finish(); return }

        val prefs = getSharedPreferences("cevir", Context.MODE_PRIVATE)
        val src = prefs.getString("src", "tr") ?: "tr"
        val tgt = prefs.getString("tgt", "en") ?: "en"
        val opts = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.fromLanguageTag(src) ?: TranslateLanguage.TURKISH)
            .setTargetLanguage(TranslateLanguage.fromLanguageTag(tgt) ?: TranslateLanguage.ENGLISH)
            .build()
        val translator = Translation.getClient(opts)

        val body = TextView(this).apply {
            text = "Çevriliyor…"
            textSize = 16f
            setTextColor(Pal.TEXT)
            setPadding(40, 20, 40, 20)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Çeviri")
            .setView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(body)
            })
            .setPositiveButton("Kopyala") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("ceviri", body.text.toString()))
                Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Kapat", null)
            .setOnDismissListener { translator.close(); finish() }
            .create()
        dialog.show()

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(selectedText)
                    .addOnSuccessListener { r -> body.text = r }
                    .addOnFailureListener { body.text = "Çeviri yapılamadı." }
            }
            .addOnFailureListener { body.text = "Dil paketi indirilemedi (internet gerekli)." }
    }
}
