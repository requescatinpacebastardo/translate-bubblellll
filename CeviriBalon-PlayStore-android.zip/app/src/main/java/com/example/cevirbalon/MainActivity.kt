package com.example.cevirbalon

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.content.edit

// Nord esintili, sakin ve profesyonel renk paleti
object Pal {
    const val BACKGROUND = 0xFFF4F6FA.toInt()
    const val CARD = 0xFFFFFFFF.toInt()
    const val TEXT = 0xFF2E3440.toInt()
    const val MUTED = 0xFF8891A3.toInt()
    const val ACCENT = 0xFF5E81AC.toInt()
    const val ACCENT_SOFT = 0xFFD8E3F0.toInt()
    const val OK = 0xFF7FB88A.toInt()
}

data class Lang(val code: String, val label: String)

object Langs {
    val list = listOf(
        Lang("en", "İngilizce"), Lang("de", "Almanca"), Lang("fr", "Fransızca"),
        Lang("es", "İspanyolca"), Lang("ru", "Rusça"), Lang("ar", "Arapça"),
        Lang("it", "İtalyanca"), Lang("pt", "Portekizce"), Lang("nl", "Felemenkçe"),
        Lang("pl", "Lehçe"), Lang("ja", "Japonca"), Lang("ko", "Korece"),
        Lang("zh", "Çince"), Lang("tr", "Türkçe")
    )
}

class MainActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var sourceSpinner: Spinner
    private lateinit var targetSpinner: Spinner

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(36, 32, 36, 32)
        val bg = GradientDrawable()
        bg.cornerRadius = 28f
        bg.setColor(Pal.CARD)
        l.background = bg
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 28
        l.layoutParams = lp
        return l
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Pal.TEXT)
        setPadding(0, 0, 0, 16)
    }

    private fun button(text: String, bgColor: Int, fg: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(fg)
        val bg = GradientDrawable()
        bg.cornerRadius = 20f
        bg.setColor(bgColor)
        b.background = bg
        b.setPadding(28, 20, 28, 20)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("cevir", MODE_PRIVATE)

        val root = ScrollView(this)
        root.setBackgroundColor(Pal.BACKGROUND)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, 0, 0, 48)
        root.addView(col)

        // ---------- Hero: low-poly arka plan + büyük "nasıl çalışır" butonu ----------
        val hero = FrameLayout(this)
        val heroBg = ImageView(this)
        heroBg.setImageResource(R.drawable.bg_hero)
        heroBg.scaleType = ImageView.ScaleType.CENTER_CROP
        hero.addView(heroBg, FrameLayout.LayoutParams(-1, dp(380)))

        val heroCol = LinearLayout(this)
        heroCol.orientation = LinearLayout.VERTICAL
        heroCol.gravity = Gravity.CENTER_HORIZONTAL
        heroCol.setPadding(0, dp(68), 0, dp(24))

        val headerTitle = TextView(this).apply {
            text = "Çeviri Balonu"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        heroCol.addView(headerTitle)
        val headerSub = TextView(this).apply {
            text = "Seç, dokun, çevir"
            textSize = 12f
            setTextColor(0xFFCBD9EA.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 0)
        }
        heroCol.addView(headerSub)

        val spacerTop = Space(this); spacerTop.layoutParams = LinearLayout.LayoutParams(-1, dp(32))
        heroCol.addView(spacerTop)

        val ringSize = dp(170)
        val ring = FrameLayout(this)
        ring.layoutParams = LinearLayout.LayoutParams(ringSize, ringSize).apply { gravity = Gravity.CENTER_HORIZONTAL }
        val ringBg = GradientDrawable()
        ringBg.shape = GradientDrawable.OVAL
        ringBg.setColor(0x33FFFFFF)
        ring.background = ringBg

        val innerBtn = FrameLayout(this)
        val innerSize = dp(132)
        val innerLp = FrameLayout.LayoutParams(innerSize, innerSize)
        innerLp.gravity = Gravity.CENTER
        innerBtn.layoutParams = innerLp
        val innerBg = GradientDrawable()
        innerBg.shape = GradientDrawable.OVAL
        innerBg.setColor(Pal.ACCENT)
        innerBg.setStroke(dp(3), Color.WHITE)
        innerBtn.background = innerBg
        innerBtn.elevation = dp(6).toFloat()
        innerBtn.isClickable = true

        val icon = ImageView(this)
        icon.setImageResource(R.mipmap.ic_launcher)
        icon.scaleType = ImageView.ScaleType.CENTER_CROP
        val iconSize = dp(86)
        val iconLp = FrameLayout.LayoutParams(iconSize, iconSize)
        iconLp.gravity = Gravity.CENTER
        icon.layoutParams = iconLp
        icon.clipToOutline = true
        icon.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: android.view.View, outline: android.graphics.Outline) {
                outline.setOval(0, 0, iconSize, iconSize)
            }
        }
        innerBtn.addView(icon)
        ring.addView(innerBtn)
        heroCol.addView(ring)

        val spacerMid = Space(this); spacerMid.layoutParams = LinearLayout.LayoutParams(-1, dp(18))
        heroCol.addView(spacerMid)

        val powerLabel = TextView(this).apply {
            text = "NASIL KULLANILIR?"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        }
        heroCol.addView(powerLabel)

        innerBtn.setOnClickListener { showHowToDialog() }

        hero.addView(heroCol, FrameLayout.LayoutParams(-1, -2))
        col.addView(hero)

        // ---------- Alt içerik ----------
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(36, 32, 36, 0)
        col.addView(content)

        val langCard = card()
        langCard.addView(title("Kaynak dil"))
        sourceSpinner = Spinner(this)
        langCard.addView(sourceSpinner)
        val sp1 = Space(this); sp1.layoutParams = LinearLayout.LayoutParams(-1, 20)
        langCard.addView(sp1)
        langCard.addView(title("Hedef dil"))
        targetSpinner = Spinner(this)
        langCard.addView(targetSpinner)
        content.addView(langCard)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Langs.list.map { it.label })
        sourceSpinner.adapter = adapter
        targetSpinner.adapter = adapter
        val savedSrc = prefs.getString("src", "tr")
        val savedTgt = prefs.getString("tgt", "en")
        sourceSpinner.setSelection(Langs.list.indexOfFirst { it.code == savedSrc }.coerceAtLeast(0))
        targetSpinner.setSelection(Langs.list.indexOfFirst { it.code == savedTgt }.coerceAtLeast(0))

        val saveBtn = button("Dilleri kaydet", Pal.ACCENT, Color.WHITE) {
            prefs.edit {
                putString("src", Langs.list[sourceSpinner.selectedItemPosition].code)
                putString("tgt", Langs.list[targetSpinner.selectedItemPosition].code)
            }
            Toast.makeText(this, "Kaydedildi. İlk kullanımda dil paketi bir kez indirilecek.", Toast.LENGTH_LONG).show()
        }
        val sp2 = Space(this); sp2.layoutParams = LinearLayout.LayoutParams(-1, 20)
        content.addView(sp2)
        content.addView(saveBtn)

        val sp3 = Space(this); sp3.layoutParams = LinearLayout.LayoutParams(-1, 28)
        content.addView(sp3)
        val infoCard = card()
        infoCard.addView(title("Nasıl kullanılır"))
        val info = TextView(this)
        info.text = "1) Yukarıdan kaynak ve hedef dili seç, kaydet.\n\n" +
                "2) Herhangi bir uygulamada (mesajlaşma, tarayıcı, not vb.) çevirmek " +
                "istediğin yazıyı parmağınla basılı tutup seç.\n\n" +
                "3) Açılan menüde \"Çeviri Balonu ile çevir\" seçeneğine dokun.\n\n" +
                "4) Çeviri küçük bir pencerede görünür, \"Kopyala\" ile panoya alabilirsin.\n\n" +
                "Bu uygulama özel/hassas bir izin istemez; yalnızca seçtiğin metni çevirir."
        info.textSize = 13f
        info.setTextColor(Pal.MUTED)
        info.setLineSpacing(5f, 1f)
        infoCard.addView(info)
        content.addView(infoCard)

        setContentView(root)
    }

    private fun showHowToDialog() {
        AlertDialog.Builder(this)
            .setTitle("Nasıl kullanılır?")
            .setMessage(
                "1) Herhangi bir yerde bir metni basılı tutup seç.\n\n" +
                "2) Açılan menüden \"Çeviri Balonu ile çevir\"e dokun.\n\n" +
                "3) Çeviri küçük bir pencerede görünür, istersen kopyala."
            )
            .setPositiveButton("Anladım", null)
            .show()
    }
}
